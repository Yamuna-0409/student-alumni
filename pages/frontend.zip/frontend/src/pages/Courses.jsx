import React, { useEffect, useState } from "react";
import API from "../services/api";
import CourseCard from "../components/CourseCard";

export default function Courses() {
  const [list, setList] = useState([]);
  const [form, setForm] = useState({ title: "", description: "", duration: "", link: "" });
  const user = JSON.parse(localStorage.getItem("user") || "null");

  useEffect(() => {
    fetchList();
  }, []);

  async function fetchList() {
    try {
      const res = await API.get("/courses");
      setList(res.data);
    } catch (err) {
      console.error("Failed to fetch courses:", err);
    }
  }

  async function submit(e) {
    e.preventDefault();
    try {
      await API.post("/courses", form);
      setForm({ title: "", description: "", duration: "", link: "" });
      fetchList();
    } catch (err) {
      alert(err.response?.data?.msg || err.message || "Error creating course");
    }
  }

  return (
    <div className="page">
      <h2>Courses</h2>

      {user && (
        <section className="card">
          <h3>Share Course</h3>
          <form onSubmit={submit} className="stack">
            <input
              placeholder="Title"
              value={form.title}
              onChange={e => setForm({ ...form, title: e.target.value })}
              required
            />
            <input
              placeholder="Duration"
              value={form.duration}
              onChange={e => setForm({ ...form, duration: e.target.value })}
              required
            />
            <textarea
              placeholder="Description"
              value={form.description}
              onChange={e => setForm({ ...form, description: e.target.value })}
              required
            />
            <input
              placeholder="Link"
              value={form.link}
              onChange={e => setForm({ ...form, link: e.target.value })}
              required
            />
            <button type="submit" className="btn-primary">Create</button>
          </form>
        </section>
      )}

      <section className="grid">
        {list.map(c => <CourseCard key={c._id || c.id} course={c} />)}
      </section>
    </div>
  );
}