import React from "react";
import { Link } from "react-router-dom";

export default function Home() {
  return (
    <section>
      <div className="hero">
        <h1>AlumniConnect</h1>
        <p>Connect with alumni, view internships, and access learning resources.</p>
        <Link to="/internships" className="btn-primary">Explore Internships</Link>
      </div>
    </section>
  );
}
