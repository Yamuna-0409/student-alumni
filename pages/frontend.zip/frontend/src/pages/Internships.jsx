import React, { useEffect, useState } from "react";
import API from "../services/api";
import InternshipCard from "../components/internshipcard";

export default function Internships() {
  const [list, setList] = useState([]);
  const [form, setForm] = useState({ title: "", company: "", type: "", location: "", stipend: "", description: "", requirements: "" });
  const user = JSON.parse(localStorage.getItem("user") || "null");

  useEffect(() => {
    fetchList();
  }, []);

  async function fetchList() {
    try {
      const res = await API.get("/internships");
      setList(res.data);
    } catch (err) {
      console.error(err);
    }
  }

  async function submit(e) {
    e.preventDefault();
    try {
      const payload = { ...form, requirements: form.requirements ? form.requirements.split(",").map(s => s.trim()) : [] };
      await API.post("/internships", payload);
      setForm({ title: "", company: "", type: "", location: "", stipend: "", description: "", requirements: "" });
      fetchList();
    } catch (err) {
      alert(err.response?.data?.msg || "Error creating internship");
    }
  }

  return (
    <div className="page">
      <h2>Internships</h2>

      {user && (
        <section className="card">
          <h3>Post Internship</h3>
          <form onSubmit={submit} className="stack">
            <input placeholder="Title" value={form.title} onChange={e=>setForm({...form, title:e.target.value})} required/>
            <input placeholder="Company" value={form.company} onChange={e=>setForm({...form, company:e.target.value})}/>
            <input placeholder="Type (Paid/Unpaid/Remote)" value={form.type} onChange={e=>setForm({...form, type:e.target.value})}/>
            <input placeholder="Location" value={form.location} onChange={e=>setForm({...form, location:e.target.value})}/>
            <input placeholder="Stipend" value={form.stipend} onChange={e=>setForm({...form, stipend:e.target.value})}/>
            <textarea placeholder="Description" value={form.description} onChange={e=>setForm({...form, description:e.target.value})}/>
            <input placeholder="Requirements (comma separated)" value={form.requirements} onChange={e=>setForm({...form, requirements:e.target.value})}/>
            <button type="submit" className="btn-primary">Create</button>
          </form>
        </section>
      )}

      <section className="grid">
        {list.map(i => <InternshipCard key={i._id} internship={i} />)}
      </section>
    </div>
  );
}
