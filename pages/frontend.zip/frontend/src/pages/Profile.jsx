import React from "react";

export default function Profile() {
  const user = JSON.parse(localStorage.getItem("user") || "null");
  if (!user) {
    return <div className="card">Please login to view profile.</div>;
  }
  return (
    <div className="card">
      <h2>{user.name}</h2>
      <p><strong>Email:</strong> {user.email}</p>
    </div>
  );
}
