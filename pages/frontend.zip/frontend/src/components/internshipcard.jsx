import React from "react";

export default function InternshipCard({ internship }) {
  return (
    <div className="card internship-card">
      <div className="card-header">
        <h3>{internship.title}</h3>
        <span className="chip">{internship.type || "Internship"}</span>
      </div>
      <p className="muted">{internship.company} — {internship.location}</p>
      <p>{internship.description}</p>
      {internship.requirements && internship.requirements.length > 0 && (
        <>
          <h4>Requirements</h4>
          <ul>{internship.requirements.map((r, i) => <li key={i}>{r}</li>)}</ul>
        </>
      )}
    </div>
  );
}
