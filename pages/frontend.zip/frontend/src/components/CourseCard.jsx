import React from "react";

export default function CourseCard({ course }) {
  return (
    <div className="card course-card">
      <h3>{course.title}</h3>
      <p className="muted">{course.duration}</p>
      <p>{course.description}</p>
      {course.link && <a href={course.link} target="_blank" rel="noreferrer">Course link</a>}
    </div>
  );
}
