import React from "react";

export default function Footer() {
  return (
    <footer className="footer">
      <div>© {new Date().getFullYear()} AlumniConnect — Bridging students & alumni.</div>
    </footer>
  );
}
